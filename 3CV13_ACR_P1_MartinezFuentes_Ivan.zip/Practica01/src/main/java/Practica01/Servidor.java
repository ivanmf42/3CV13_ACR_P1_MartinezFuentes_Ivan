package Practica01;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Servidor{
    public static void main(String[] args) {
        try{
            int puerto = 8000;
            /*
            //Esto solo se usará en caso de que se desee cambiar el puerto
            System.out.println("Introduzca el número de puerto\n");
            puerto = Integer.parseInt(br.readLine());
             */

            ServerSocket servidor = new ServerSocket(puerto);
            System.out.println("Conexion iniciada");

            List<Producto> productoList = new ArrayList<>();

            Producto productoVacio = new Producto();
            Producto lapiz = new Producto(1, "Lapiz Numero 2", (float) 10.0, 100);
            Producto pluma = new Producto(2, "Pluma negra", (float) 20.0, 100);
            Producto sacapuntas = new Producto(3, "Sacapuntas", (float) 30.0, 100);
            Producto goma = new Producto(4, "Goma de borrar", (float) 40.0, 120);
            Producto pegamento = new Producto(5, "Pegamento en barra", (float) 50.0, 130);
            Producto colores = new Producto(6, "Caja de colores", (float) 60.0, 125);
            Producto libreta = new Producto(7, "Libreta", (float) 70.0, 135);
            productoList.add(productoVacio);
            productoList.add(lapiz);
            productoList.add(pluma);
            productoList.add(sacapuntas);
            productoList.add(goma);
            productoList.add(pegamento);
            productoList.add(colores);
            productoList.add(libreta);
            while(true){
                Socket socket = servidor.accept();
                System.out.println("Nueva conexion establecida con " + socket.getInetAddress() + ":" + socket.getPort());
                
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String opcion = br.readLine();
                System.out.println(opcion);

                System.out.println("Se eligio: " + opcion + ":");

                switch(Integer.parseInt(opcion)){
                    case 1:
                        System.out.println("Enviando catálogo de productos al cliente\n");
                        try {
                            FileOutputStream fileOutputStream = new FileOutputStream("catalogo.txt");
                            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
                            objectOutputStream.writeObject(productoList);
                            System.out.println("Objeto serializado exitosamente: " + fileOutputStream.toString());
                            objectOutputStream.flush();
                            objectOutputStream.close();
                            fileOutputStream.close();

                        } catch (IOException i) {
                            i.printStackTrace();
                        }
                        break;
                    case 2:
                        System.out.println("Enviando imagenes al cliente\n");
                        // send file

                        //File file = new File ("C:\\Practica01\\servidor\\img.zip");
                        File file = new File ("/Users/i0m0457/Downloads/Practica01/servidor/img.zip");
                        byte [] mybytearray  = new byte [(int)file.length()];
                        FileInputStream fileInputStream = new FileInputStream(file);
                        BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
                        bufferedInputStream.read(mybytearray,0,mybytearray.length);
                        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        System.out.println("Enviando (" + mybytearray.length + " bytes)");
                        objectOutputStream.write(mybytearray,0,mybytearray.length);
                        objectOutputStream.flush();
                        objectOutputStream.close();
                        break;
                    case 3:
                        ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                        Producto producto = (Producto) objectInputStream.readObject();
                        System.out.println(producto.getExistencias() + " unidades del producto " + producto.getId() + " agregadas exitosamente al carrito\n");
                        productoList.get(producto.getId()).setExistencias(productoList.get(producto.getId()).getExistencias() - producto.getExistencias());
                        break;
                    case 4:
                        System.out.println("Realizando venta\n");
                        break;
                    case 5:
                        System.out.println("Terminando venta\n");
                        socket.close();
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        socket.close();
                        break;
                }
            }
        }catch (IOException | NumberFormatException | ClassNotFoundException e){
            e.printStackTrace(System.out);
        }
    }
}