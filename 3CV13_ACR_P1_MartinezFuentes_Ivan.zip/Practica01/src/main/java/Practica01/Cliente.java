package Practica01;

import java.io.*;
import java.net.Socket;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class Cliente {
    public static void main(String[] args) throws IOException {
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String direccion = "127.0.0.1";
            int puerto = 8000;
            int opcion = 0;

            int id = 0;
            int cantidad=0;
            float precioTotal = 0;
            Producto productoElegido = new Producto();
            List<Producto> productoList = new ArrayList<>();
            List<Producto> productoCompradoList = new ArrayList<>();
            Map<Integer, Integer> productosElegidosMap = new HashMap<>();

            Socket cliente = null;

            /*
            //Esto solo se usará en caso de que se desee cambiar la dirección y el puerto
            System.out.println("Introduzca la dirección del servidor\n");
            direccion = br.readLine();
            System.out.println("Introduzca el número de puerto\n");
            puerto = Integer.parseInt(br.readLine());
             */

            while(opcion != 5){
                
                cliente = new Socket(direccion, puerto);

                System.out.println("Elige una opción del menú:\n");
                System.out.println("1.- Ver el catálogo de productos\n");
                System.out.println("2.- Ver imágenes de los productos\n");
                System.out.println("3.- Agregar producto al carrito de compras\n");
                System.out.println("4.- Comprar carrito\n");
                System.out.println("5.- Finalizar transacción\n");
                opcion = Integer.parseInt(br.readLine());

                PrintWriter pw = new PrintWriter(new OutputStreamWriter(cliente.getOutputStream()));
                pw.println(opcion);
                pw.flush();
                switch(opcion){
                        case 1:
                            try {
                                FileInputStream fileInputStream
                                        = new FileInputStream("catalogo.txt");
                                ObjectInputStream objectInputStream
                                        = new ObjectInputStream(fileInputStream);
                                productoList = (List<Producto>) objectInputStream.readObject();
                                objectInputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (ClassNotFoundException e) {
                                e.printStackTrace();
                            }
                            System.out.println("El catálogo se encuentra disponible en el archivo \"catalogo.txt\"\n");
                            break;

                        case 2:
                            try {
                                // receive file
                                String FILE_TO_RECEIVED = "cliente/img.zip";
                                int FILE_SIZE = Integer.MAX_VALUE/2;
                                byte [] mybytearray  = new byte [FILE_SIZE];
                                InputStream inputStream = cliente.getInputStream();
                                FileOutputStream fileOutputStream = new FileOutputStream(FILE_TO_RECEIVED);
                                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                                int bytesRead = inputStream.read(mybytearray, 0, mybytearray.length);
                                int current = bytesRead;

                                do {
                                    bytesRead =
                                            inputStream.read(mybytearray, current, (mybytearray.length-current));
                                    if(bytesRead >= 0) current += bytesRead;
                                } while(bytesRead > -1);

                                bufferedOutputStream.write(mybytearray, 0 , current);
                                bufferedOutputStream.flush();
                                System.out.println("File " + FILE_TO_RECEIVED
                                        + " downloaded (" + current + " bytes read)");
                                bufferedOutputStream.close();
                                fileOutputStream.close();
                            } catch (IOException i) {
                                i.printStackTrace();
                                return;
                            }
                            System.out.println("Las imágenes se encuentran disponibles en el archivo \"img.zip\"\n");
                            break;

                        case 3:
                            System.out.println("Introduzca el id del producto deseado\n");
                            id = Integer.parseInt(br.readLine());
                            System.out.println("Introduzca la cantidad del producto deseado\n");
                            cantidad = Integer.parseInt(br.readLine());
                            if(cantidad<productoList.get(id).getExistencias()) {
                                productoElegido.setId(id);
                                productoElegido.setExistencias(cantidad);
                                ObjectOutputStream objectOutputStream = new ObjectOutputStream(cliente.getOutputStream());
                                objectOutputStream.writeObject(productoElegido);
                                System.out.println("Enviando al servidor " + direccion + ":" + puerto + "\n");
                                System.out.println("Has seleccionado " + cantidad + "unidades del producto con id " + id + "\n");
                                productosElegidosMap.put(id, cantidad);
                                productoList.get(id).setExistencias(productoList.get(id).getExistencias()-cantidad);
                            } else {
                                System.out.println("No hay suficientes existencias del producto: " + id + "\n");

                            }
                            break;

                        case 4:
                            System.out.println("Realizando compra del carrito:\n");
                            Iterator<Map.Entry<Integer, Integer>> iterator = productosElegidosMap.entrySet().iterator();
                            while(iterator.hasNext()) {
                                Map.Entry<Integer, Integer> entry = iterator.next();
                                int auxiliar = entry.getKey();
                                Producto productoComprado = new Producto(entry.getKey(), productoList.get(entry.getKey()).getNombre(), productoList.get(entry.getKey()).getPrecio(), entry.getValue());
                                productoCompradoList.add(productoComprado);
                                precioTotal+= productoComprado.getPrecio()* productoComprado.getExistencias();
                                System.out.println("Key = " + entry.getKey() +
                                        ", Value = " + entry.getValue());
                            }

                            System.out.println("Importe total a pagar: " + precioTotal);
                            break;

                        case 5:
                            if(!productoCompradoList.isEmpty()) {
                                System.out.println("Generando el ticket de compra");
                                Document document = new Document();
                                PdfWriter.getInstance(document, new FileOutputStream("ticket.pdf"));

                                document.open();
                                Font font = FontFactory.getFont(FontFactory.COURIER, 10, BaseColor.BLACK);
                                Chunk encabezado = new Chunk("Ticket de compra\n\n", font);
                                Chunk total = new Chunk("\n\nPrecio total a pagar: $" + precioTotal + " MXN", font);
                                document.add(total);

                                document.add(encabezado);

                                PdfPTable table = new PdfPTable(5);
                                addTableHeader(table);
                                addRows(table, productoCompradoList);

                                document.add(table);
                                document.close();
                            } else {
                                System.out.println("No hay productos agregados al carrito, imposible generar ticket");
                            }
                            break;

                        default:
                            System.out.println("Elige una opción válida del menú");
                            break;
                }
            }

        }catch (IOException | NumberFormatException | DocumentException e){
            e.printStackTrace(System.out);
        }
    }
    private static void addTableHeader(PdfPTable table) {
        String[] headers = {"Id", "Item", "Precio Unitario", "Unidades", "Precio"};
        for (String headerString: headers) {
            Stream.of(headerString)
                    .forEach(columnTitle -> {
                        PdfPCell header = new PdfPCell();
                        header.setBackgroundColor(BaseColor.LIGHT_GRAY);
                        header.setBorderWidth(2);
                        header.setPhrase(new Phrase(columnTitle));
                        table.addCell(header);
                    });
        }
    }

    private static void addRows(PdfPTable table, List<Producto> productoCompradoList) {
        Iterator<Producto> iterator= productoCompradoList.iterator();
        Integer id;
        String nombre;
        Float precio;
        Float precioTotalItem;
        Integer unidades;
        if(!productoCompradoList.isEmpty()) {
            System.out.println("Imprimiendo el ticket de compra");
            while (iterator.hasNext()) {
                Producto producto;
                producto = iterator.next();
                id = producto.getId();
                nombre = producto.getNombre();
                precio = producto.getPrecio();
                unidades = producto.getExistencias();
                precioTotalItem = precio * unidades;
                table.addCell(id.toString());
                table.addCell(nombre);
                table.addCell(precioTotalItem.toString());
                table.addCell(unidades.toString());
                table.addCell(precioTotalItem.toString());
            }
        }
    }
}
